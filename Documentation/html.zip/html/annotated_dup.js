var annotated_dup =
[
    [ "BoardState", "struct_board_state.html", "struct_board_state" ],
    [ "BtnPos", "struct_btn_pos.html", "struct_btn_pos" ],
    [ "Dataset", "struct_dataset.html", "struct_dataset" ],
    [ "PlayerMode", "struct_player_mode.html", "struct_player_mode" ],
    [ "Position", "struct_position.html", "struct_position" ]
];