var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "elapsedTime.c", "elapsed_time_8c.html", "elapsed_time_8c" ],
    [ "importData.c", "import_data_8c.html", "import_data_8c" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "minimax.c", "minimax_8c.html", "minimax_8c" ],
    [ "ml-naive-bayes.c", "ml-naive-bayes_8c.html", "ml-naive-bayes_8c" ]
];