var struct_board_state =
[
    [ "bestMove", "struct_board_state.html#abac4e5d9337901878b415c9fa72160a7", null ],
    [ "board", "struct_board_state.html#a57b9f8c3a06f5141eea6b5d22c4c4eb9", null ]
];