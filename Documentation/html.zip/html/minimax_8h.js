var minimax_8h =
[
    [ "BoardState", "struct_board_state.html", "struct_board_state" ],
    [ "FILE_BESTMOV", "minimax_8h.html#a639effcb37d2b98906303fecdb9c9f5e", null ],
    [ "MAX_BOARDS", "minimax_8h.html#a09d570e408c9e6ed66026c7ae5713473", null ],
    [ "checkAndUpdateBestMove", "minimax_8h.html#a877aa8e7e6b5f77be1c8b5990e5d1625", null ],
    [ "evaluate", "minimax_8h.html#a7eb0ef2ef587e3148bc0811943f7ec13", null ],
    [ "findBestMove", "minimax_8h.html#a0efa6e5041878576ac8e039fab89e046", null ],
    [ "isMovesLeft", "minimax_8h.html#a3df458be79a64addf900a0dda94ae53d", null ],
    [ "loadBoardStates", "minimax_8h.html#ad96b1cb65a3cf3189660045f9351e66b", null ],
    [ "max", "minimax_8h.html#af082905f7eac6d03e92015146bbc1925", null ],
    [ "min", "minimax_8h.html#abd8bbcfabb3ddef2ccaafb9928a37b95", null ],
    [ "minimax", "minimax_8h.html#a5f4a74701aaef2a7cae76669feeea456", null ],
    [ "printFileContents", "minimax_8h.html#aebb81db22ed3bba673d41fef99ffc9fd", null ],
    [ "writeBestMoveToFile", "minimax_8h.html#a887a1c4feb6adb0ec61b30ced51619eb", null ]
];