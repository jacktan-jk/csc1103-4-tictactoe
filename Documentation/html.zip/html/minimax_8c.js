var minimax_8c =
[
    [ "checkAndUpdateBestMove", "minimax_8c.html#a877aa8e7e6b5f77be1c8b5990e5d1625", null ],
    [ "evaluate", "minimax_8c.html#a7eb0ef2ef587e3148bc0811943f7ec13", null ],
    [ "findBestMove", "minimax_8c.html#a0efa6e5041878576ac8e039fab89e046", null ],
    [ "isMovesLeft", "minimax_8c.html#a3df458be79a64addf900a0dda94ae53d", null ],
    [ "loadBoardStates", "minimax_8c.html#ad96b1cb65a3cf3189660045f9351e66b", null ],
    [ "max", "minimax_8c.html#af082905f7eac6d03e92015146bbc1925", null ],
    [ "min", "minimax_8c.html#abd8bbcfabb3ddef2ccaafb9928a37b95", null ],
    [ "minimax", "minimax_8c.html#a5f4a74701aaef2a7cae76669feeea456", null ],
    [ "writeBestMoveToFile", "minimax_8c.html#a887a1c4feb6adb0ec61b30ced51619eb", null ],
    [ "depthCounter", "minimax_8c.html#aa8d38a95bc17bcaa7a8bb193e84af817", null ]
];