var macros_8h =
[
    [ "Position", "struct_position.html", "struct_position" ],
    [ "BAD_PARAM", "macros_8h.html#adb25c89db5336fcc8b27359a183a6daa", null ],
    [ "BOT", "macros_8h.html#a8729a567b846ff767c1fbf87fd5725e8", null ],
    [ "CLASSES", "macros_8h.html#aa6df04fbcd3d2e5765447931df2c3d19", null ],
    [ "DATA_SIZE", "macros_8h.html#af55149bc1f05cf18af067a302e31e3f9", null ],
    [ "DEBUG", "macros_8h.html#ad72dbcf6d0153db1b8d8a58001feed83", null ],
    [ "DISABLE_ASM", "macros_8h.html#a5ae05ae4c72cd9ae5147a40a1436cef6", null ],
    [ "DISABLE_ELAPSED", "macros_8h.html#aacc47b301ed91254362ba4f2cd7efc75", null ],
    [ "DISABLE_LOOKUP", "macros_8h.html#a47dca33d219deb503db9c9d808b24356", null ],
    [ "EMPTY", "macros_8h.html#a2b7cf2a3641be7b89138615764d60ba3", null ],
    [ "ERROR", "macros_8h.html#a8fe83ac76edc595f6b98cd4a4127aed5", null ],
    [ "MINIMAX_GODMODE", "macros_8h.html#a0223dfa64002c42b357e8f4f46dc139f", null ],
    [ "MODE_2P", "macros_8h.html#a733c98a18575d60db109addf4efa956a", null ],
    [ "MODE_ML", "macros_8h.html#ad6f35c3ff19e8e5cf4d8e4859e3240d1", null ],
    [ "MODE_MM", "macros_8h.html#a86d9cfb06869d7709dbdcfd5c0515e90", null ],
    [ "PLAY", "macros_8h.html#a34deddb3d2e1791fd7ce5acc13ffc8df", null ],
    [ "PLAYER1", "macros_8h.html#aff32b2add5186520b5ae86864ebaf51a", null ],
    [ "PRINT_DEBUG", "macros_8h.html#a77496f90d44d7937b09d66c65d23991d", null ],
    [ "SUCCESS", "macros_8h.html#aa90cac659d18e8ef6294c7ae337f6b58", null ],
    [ "TIE", "macros_8h.html#a047b752526fa845a214fbd2dda59bdaa", null ],
    [ "WIN", "macros_8h.html#a43105771f16e2da3078149f0de528e9b", null ]
];