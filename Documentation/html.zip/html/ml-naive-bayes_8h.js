var ml_naive_bayes_8h =
[
    [ "CLASSES", "ml-naive-bayes_8h.html#aa6df04fbcd3d2e5765447931df2c3d19", null ],
    [ "TESTING_DATA_SIZE", "ml-naive-bayes_8h.html#a5f4f4db0f77efc9e06b59f3574a93818", null ],
    [ "TRAINING_DATA_SIZE", "ml-naive-bayes_8h.html#a3b72bac4ef32b693683e40a632c40acf", null ],
    [ "assignCMValue", "ml-naive-bayes_8h.html#ad2a4ca79d29276c99f36cc583b47c6c3", null ],
    [ "assignMoveIndex", "ml-naive-bayes_8h.html#a50b257da463de74ba2358056e85342ff", null ],
    [ "calcConfusionMatrix", "ml-naive-bayes_8h.html#a0994d944dcdbc157e60c5b96a2c27fdf", null ],
    [ "calcTrainErrors", "ml-naive-bayes_8h.html#a4d2eddd8e919b0f28a86c5d0f820a269", null ],
    [ "calculateProbabilities", "ml-naive-bayes_8h.html#a112adbcfbb6027bb85c8150c15c3d98b", null ],
    [ "debugDataset", "ml-naive-bayes_8h.html#a39fc66cfb4519ce0e0840bc766cb79e0", null ],
    [ "getBestPosition", "ml-naive-bayes_8h.html#adb6b2fbadefdff0ed94d6ef2e0ef176c", null ],
    [ "getTruthValue", "ml-naive-bayes_8h.html#ae6c5693fa5f2aef85092855a1a83ba08", null ],
    [ "initData", "ml-naive-bayes_8h.html#a1d519f1ac761ee87a5de63ff461958ca", null ],
    [ "predictOutcome", "ml-naive-bayes_8h.html#a47ee49cedcea70023c8789c6431b67e6", null ],
    [ "resetTrainingData", "ml-naive-bayes_8h.html#abf660c40d72d1de487ad5a16a7155d66", null ]
];