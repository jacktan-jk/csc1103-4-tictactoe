var struct_dataset =
[
    [ "grid", "struct_dataset.html#afda761d4a86b83805f114e9c7aae1fc6", null ],
    [ "outcome", "struct_dataset.html#a207163fc7e81ca487088a1f8ad958a89", null ]
];