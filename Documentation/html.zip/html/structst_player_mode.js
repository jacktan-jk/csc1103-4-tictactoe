var structst_player_mode =
[
    [ "mode", "structst_player_mode.html#a1ea5d0cb93f22f7d0fdf804bd68c3326", null ],
    [ "txt", "structst_player_mode.html#abeea1413a2ae6c3b17cb7cb859452252", null ]
];