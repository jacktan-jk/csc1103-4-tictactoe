var import_data_8h =
[
    [ "Dataset", "struct_dataset.html", "struct_dataset" ],
    [ "DATA_PATH", "import_data_8h.html#ac26a668e32beeb7eae8b6e4adbe5d1e1", null ],
    [ "RES_PATH", "import_data_8h.html#a793644bd88146828177a2a4f57e3bf01", null ],
    [ "TEST_PATH", "import_data_8h.html#a5966a44df244da9e3b2aab95cb69adc1", null ],
    [ "TRAIN_PATH", "import_data_8h.html#ae0d3caefdba95baf2009a1db6d4d5380", null ],
    [ "getRandomNo", "import_data_8h.html#a516cae4e8116d0b4b9268cd6768487f6", null ],
    [ "getTestingData", "import_data_8h.html#af70ae09f2665c0a3de0a14322fe4b107", null ],
    [ "getTrainingData", "import_data_8h.html#a4ee672f09716ad82ade7b665d807b07a", null ],
    [ "readDataset", "import_data_8h.html#a5129a12fff19bf634c22a38f960e14b3", null ],
    [ "splitFile", "import_data_8h.html#a23268cdefc193ff7a241e3839538f2a1", null ]
];