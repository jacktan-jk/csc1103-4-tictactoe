var index =
[
    [ "Installation Instructions (Linux)", "index.html#installation-instructions-linux", [
      [ "Building the Project via Docker (Linux)", "index.html#building-the-project-via-docker-linux", [
        [ "[OPTIONAL] Loading Docker Image", "index.html#optional-loading-docker-image", null ],
        [ "Build and Run TicTacToe Application on Docker (Linux)", "index.html#build-and-run-tictactoe-application-on-docker-linux", null ]
      ] ]
    ] ],
    [ "Installation Instructions (MacOS)", "index.html#installation-instructions-macos", [
      [ "Run TicTacToe Application on Docker (MacOS)", "index.html#run-tictactoe-application-on-docker-macos", null ]
    ] ],
    [ "Installation Instructions (Windows)", "index.html#installation-instructions-windows", [
      [ "Building the Project via Docker (Windows)", "index.html#building-the-project-via-docker-windows", [
        [ "[OPTIONAL] Loading Docker Image", "index.html#optional-loading-docker-image-1", null ],
        [ "Build and Run TicTacToe Application on Docker (Windows)", "index.html#build-and-run-tictactoe-application-on-docker-windows", null ]
      ] ],
      [ "Build and Run the Project in Windows (w/o Docker)", "index.html#build-and-run-the-project-in-windows-wo-docker", null ]
    ] ],
    [ "BASIC REQUIREMENTS (BOTH)", "index.html#basic-requirements-both", null ],
    [ "[^1]PM-CSC1103 REQUIRMENTS", "index.html#autotoc_md1pm-csc1103-requirments", null ],
    [ "[^2]COA-CSC1104 REQUIRMENTS", "index.html#autotoc_md2coa-csc1104-requirments", null ]
];