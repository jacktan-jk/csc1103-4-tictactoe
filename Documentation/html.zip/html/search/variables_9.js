var searchData=
[
  ['outcome_0',['outcome',['../struct_dataset.html#a207163fc7e81ca487088a1f8ad958a89',1,'Dataset']]]
];
