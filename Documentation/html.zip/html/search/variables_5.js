var searchData=
[
  ['iboard_0',['iBoard',['../main_8c.html#adc21ea5cc28327a21455788fa1b9518f',1,'main.c']]],
  ['igamestate_1',['iGameState',['../main_8c.html#a80fa44672f562631d6347fc01e0c9a8a',1,'main.c']]],
  ['iplayer1_5fscore_2',['iPlayer1_score',['../main_8c.html#ae1d310ad434c7a2f6b36903df0e48f7f',1,'main.c']]],
  ['iplayer2_5fscore_3',['iPlayer2_score',['../main_8c.html#a8ef9076ab0a4dabeb8638b2295ccd7e8',1,'main.c']]],
  ['ismlavail_4',['isMLAvail',['../main_8c.html#a3b5a2ec67eaad775b0eedc6c869b0efa',1,'main.c']]],
  ['isplayer1turn_5',['isPlayer1Turn',['../main_8c.html#ac7d33f5c85beb77a9f9b399811ee34c6',1,'main.c']]],
  ['itie_5fscore_6',['iTie_score',['../main_8c.html#a95f308163088cd3cc0aee84261b02030',1,'main.c']]],
  ['iwinpos_7',['iWinPos',['../main_8c.html#a300a754c6a50ee6fc5e78bd8caf55f3b',1,'main.c']]]
];
