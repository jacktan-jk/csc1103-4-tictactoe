var indexSectionsWithContent =
{
  0: "12abcdefgilmnoprstuvw",
  1: "bdp",
  2: "eim",
  3: "acdefgilmoprsuw",
  4: "abcdgilmnoprt",
  5: "bcdefmprstw",
  6: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

