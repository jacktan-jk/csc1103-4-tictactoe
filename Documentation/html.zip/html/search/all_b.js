var searchData=
[
  ['html_20documentation_20strong_20_3a_0',['2. &lt;strong&gt;View the HTML Documentation&lt;/strong&gt;:',['../md__documentation_2_r_e_a_d_m_e.html#autotoc_md2-view-the-html-documentation',1,'']]]
];
