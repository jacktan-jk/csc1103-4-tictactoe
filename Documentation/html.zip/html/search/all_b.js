var searchData=
[
  ['macos_0',['MacOS',['../index.html#installation-instructions-macos',1,'Installation Instructions (MacOS)'],['../index.html#run-tictactoe-application-on-docker-macos',1,'Run TicTacToe Application on Docker (MacOS)']]],
  ['macros_2eh_1',['macros.h',['../macros_8h.html',1,'']]],
  ['main_2',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.c']]],
  ['main_2ec_3',['main.c',['../main_8c.html',1,'']]],
  ['main_2eh_4',['main.h',['../main_8h.html',1,'']]],
  ['mainpage_2emd_5',['mainpage.md',['../mainpage_8md.html',1,'']]],
  ['max_6',['max',['../minimax_8h.html#af082905f7eac6d03e92015146bbc1925',1,'max(int a, int b):&#160;minimax.c'],['../minimax_8c.html#af082905f7eac6d03e92015146bbc1925',1,'max(int a, int b):&#160;minimax.c']]],
  ['max_5fboards_7',['MAX_BOARDS',['../minimax_8h.html#a09d570e408c9e6ed66026c7ae5713473',1,'minimax.h']]],
  ['min_8',['min',['../minimax_8h.html#abd8bbcfabb3ddef2ccaafb9928a37b95',1,'min(int a, int b):&#160;minimax.c'],['../minimax_8c.html#abd8bbcfabb3ddef2ccaafb9928a37b95',1,'min(int a, int b):&#160;minimax.c']]],
  ['minimax_9',['minimax',['../minimax_8h.html#a5f4a74701aaef2a7cae76669feeea456',1,'minimax(int board[3][3], int depth, bool isMax):&#160;minimax.c'],['../minimax_8c.html#a5f4a74701aaef2a7cae76669feeea456',1,'minimax(int board[3][3], int depth, bool isMax):&#160;minimax.c']]],
  ['minimax_2ec_10',['minimax.c',['../minimax_8c.html',1,'']]],
  ['minimax_2eh_11',['minimax.h',['../minimax_8h.html',1,'']]],
  ['minimax_5fgodmode_12',['MINIMAX_GODMODE',['../macros_8h.html#a0223dfa64002c42b357e8f4f46dc139f',1,'macros.h']]],
  ['ml_2dnaive_2dbayes_2ec_13',['ml-naive-bayes.c',['../ml-naive-bayes_8c.html',1,'']]],
  ['ml_2dnaive_2dbayes_2eh_14',['ml-naive-bayes.h',['../ml-naive-bayes_8h.html',1,'']]],
  ['mode_15',['mode',['../struct_player_mode.html#a1ea5d0cb93f22f7d0fdf804bd68c3326',1,'PlayerMode']]],
  ['mode_5f2p_16',['MODE_2P',['../macros_8h.html#a733c98a18575d60db109addf4efa956a',1,'macros.h']]],
  ['mode_5fml_17',['MODE_ML',['../macros_8h.html#ad6f35c3ff19e8e5cf4d8e4859e3240d1',1,'macros.h']]],
  ['mode_5fmm_18',['MODE_MM',['../macros_8h.html#a86d9cfb06869d7709dbdcfd5c0515e90',1,'macros.h']]]
];
