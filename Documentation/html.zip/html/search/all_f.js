var searchData=
[
  ['negative_5fcount_0',['negative_count',['../ml-naive-bayes_8c.html#ab1b50144dddd58fbfd0234a97acf2961',1,'ml-naive-bayes.c']]],
  ['negativeclassprobability_1',['negativeClassProbability',['../ml-naive-bayes_8c.html#a9d460fc84c8b03ac6ea12026e466a45c',1,'ml-naive-bayes.c']]],
  ['negativemovecount_2',['negativeMoveCount',['../ml-naive-bayes_8c.html#aa83f370fa551c33731fb703c35293412',1,'ml-naive-bayes.c']]]
];
