var searchData=
[
  ['cm_0',['cM',['../ml-naive-bayes_8c.html#a81f351014ab99a023747301585cde2e0',1,'ml-naive-bayes.c']]],
  ['col_1',['col',['../struct_position.html#afb52e720f5f0c483db5861f9e42e924e',1,'Position']]]
];
