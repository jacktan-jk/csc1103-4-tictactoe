var searchData=
[
  ['macros_2eh_0',['macros.h',['../macros_8h.html',1,'']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['main_2eh_2',['main.h',['../main_8h.html',1,'']]],
  ['mainpage_2emd_3',['mainpage.md',['../mainpage_8md.html',1,'']]],
  ['minimax_2ec_4',['minimax.c',['../minimax_8c.html',1,'']]],
  ['minimax_2eh_5',['minimax.h',['../minimax_8h.html',1,'']]],
  ['ml_2dnaive_2dbayes_2ec_6',['ml-naive-bayes.c',['../ml-naive-bayes_8c.html',1,'']]],
  ['ml_2dnaive_2dbayes_2eh_7',['ml-naive-bayes.h',['../ml-naive-bayes_8h.html',1,'']]]
];
