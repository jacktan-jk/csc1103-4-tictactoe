var searchData=
[
  ['loadboardstates_0',['loadBoardStates',['../minimax_8h.html#ad96b1cb65a3cf3189660045f9351e66b',1,'loadBoardStates(struct BoardState boardStates[]):&#160;minimax.c'],['../minimax_8c.html#ad96b1cb65a3cf3189660045f9351e66b',1,'loadBoardStates(struct BoardState boardStates[]):&#160;minimax.c']]]
];
