var searchData=
[
  ['assigncmvalue_0',['assignCMValue',['../ml-naive-bayes_8h.html#ad2a4ca79d29276c99f36cc583b47c6c3',1,'assignCMValue(int actual, int predicted):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#ad2a4ca79d29276c99f36cc583b47c6c3',1,'assignCMValue(int actual, int predicted):&#160;ml-naive-bayes.c']]],
  ['assignmoveindex_1',['assignMoveIndex',['../ml-naive-bayes_8h.html#a50b257da463de74ba2358056e85342ff',1,'assignMoveIndex(char move):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a50b257da463de74ba2358056e85342ff',1,'assignMoveIndex(char move):&#160;ml-naive-bayes.c']]]
];
