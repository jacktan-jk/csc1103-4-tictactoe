var searchData=
[
  ['calcconfusionmatrix_0',['calcConfusionMatrix',['../ml-naive-bayes_8h.html#a0994d944dcdbc157e60c5b96a2c27fdf',1,'calcConfusionMatrix():&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a0994d944dcdbc157e60c5b96a2c27fdf',1,'calcConfusionMatrix():&#160;ml-naive-bayes.c']]],
  ['calctrainerrors_1',['calcTrainErrors',['../ml-naive-bayes_8h.html#a4d2eddd8e919b0f28a86c5d0f820a269',1,'calcTrainErrors():&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a4d2eddd8e919b0f28a86c5d0f820a269',1,'calcTrainErrors():&#160;ml-naive-bayes.c']]],
  ['calculateprobabilities_2',['calculateProbabilities',['../ml-naive-bayes_8h.html#a112adbcfbb6027bb85c8150c15c3d98b',1,'calculateProbabilities(int dataset_size):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a112adbcfbb6027bb85c8150c15c3d98b',1,'calculateProbabilities(int dataset_size):&#160;ml-naive-bayes.c']]],
  ['checkandupdatebestmove_3',['checkAndUpdateBestMove',['../minimax_8h.html#a877aa8e7e6b5f77be1c8b5990e5d1625',1,'checkAndUpdateBestMove(int board[3][3], struct Position *bestMove, struct BoardState boardStates[], int count):&#160;minimax.c'],['../minimax_8c.html#a877aa8e7e6b5f77be1c8b5990e5d1625',1,'checkAndUpdateBestMove(int board[3][3], struct Position *bestMove, struct BoardState boardStates[], int count):&#160;minimax.c']]],
  ['chkplayerwin_4',['chkPlayerWin',['../main_8h.html#ab3744385ac07502d3920342e20805ec7',1,'chkPlayerWin():&#160;main.c'],['../main_8c.html#ab3744385ac07502d3920342e20805ec7',1,'chkPlayerWin():&#160;main.c']]],
  ['classes_5',['CLASSES',['../macros_8h.html#aa6df04fbcd3d2e5765447931df2c3d19',1,'CLASSES:&#160;macros.h'],['../ml-naive-bayes_8h.html#aa6df04fbcd3d2e5765447931df2c3d19',1,'CLASSES:&#160;ml-naive-bayes.h']]],
  ['cleargrid_6',['clearGrid',['../main_8h.html#ad28c8c932b46ed4bce19748ba7106599',1,'clearGrid():&#160;main.c'],['../main_8c.html#ad28c8c932b46ed4bce19748ba7106599',1,'clearGrid():&#160;main.c']]],
  ['cm_7',['cM',['../ml-naive-bayes_8c.html#a81f351014ab99a023747301585cde2e0',1,'ml-naive-bayes.c']]],
  ['coa_20csc1104_20requirments_20strong_8',['&lt;strong&gt;[^2]COA-CSC1104 REQUIRMENTS&lt;/strong&gt;',['../index.html#autotoc_md2coa-csc1104-requirments',1,'']]],
  ['col_9',['col',['../struct_position.html#afb52e720f5f0c483db5861f9e42e924e',1,'Position']]],
  ['configuration_20file_20strong_20_3a_10',['1. &lt;strong&gt;Run the Doxygen Configuration File&lt;/strong&gt;:',['../md__documentation_2_r_e_a_d_m_e.html#autotoc_md1-run-the-doxygen-configuration-file',1,'']]],
  ['csc1103_20csc1104_20project_20strong_11',['&lt;strong&gt;TIC TAC TOE - CSC1103 &amp; CSC1104 Project&lt;/strong&gt;',['../index.html#tic-tac-toe---csc1103--csc1104-project',1,'']]],
  ['csc1103_20requirments_20strong_12',['&lt;strong&gt;[^1]PM-CSC1103 REQUIRMENTS&lt;/strong&gt;',['../index.html#autotoc_md1pm-csc1103-requirments',1,'']]],
  ['csc1104_20project_20strong_13',['&lt;strong&gt;TIC TAC TOE - CSC1103 &amp; CSC1104 Project&lt;/strong&gt;',['../index.html#tic-tac-toe---csc1103--csc1104-project',1,'']]],
  ['csc1104_20requirments_20strong_14',['&lt;strong&gt;[^2]COA-CSC1104 REQUIRMENTS&lt;/strong&gt;',['../index.html#autotoc_md2coa-csc1104-requirments',1,'']]]
];
