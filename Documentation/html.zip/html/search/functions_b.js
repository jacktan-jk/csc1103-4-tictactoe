var searchData=
[
  ['readdataset_0',['readDataset',['../import_data_8h.html#a5129a12fff19bf634c22a38f960e14b3',1,'readDataset(const char *filename, bool split):&#160;importData.c'],['../import_data_8c.html#a5129a12fff19bf634c22a38f960e14b3',1,'readDataset(const char *filename, bool split):&#160;importData.c']]],
  ['resettrainingdata_1',['resetTrainingData',['../ml-naive-bayes_8h.html#abf660c40d72d1de487ad5a16a7155d66',1,'resetTrainingData():&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#abf660c40d72d1de487ad5a16a7155d66',1,'resetTrainingData():&#160;ml-naive-bayes.c']]]
];
