var searchData=
[
  ['writebestmovetofile_0',['writeBestMoveToFile',['../minimax_8h.html#a887a1c4feb6adb0ec61b30ced51619eb',1,'writeBestMoveToFile(int board[3][3], struct Position bestMove):&#160;minimax.c'],['../minimax_8c.html#a887a1c4feb6adb0ec61b30ced51619eb',1,'writeBestMoveToFile(int board[3][3], struct Position bestMove):&#160;minimax.c']]]
];
