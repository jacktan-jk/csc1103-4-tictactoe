var searchData=
[
  ['test_5fpredictederrors_0',['test_PredictedErrors',['../ml-naive-bayes_8c.html#af1bf8dd0e4f0e05e4360bcabd1b2da89',1,'ml-naive-bayes.c']]],
  ['testingfile_1',['testingFile',['../import_data_8c.html#a372bb3912d20ff92d4ac1b566a824fc4',1,'importData.c']]],
  ['train_5fpredictederrors_2',['train_PredictedErrors',['../ml-naive-bayes_8c.html#ad6914c7200a9bef056b87f9ffec33e82',1,'ml-naive-bayes.c']]],
  ['trainingfile_3',['trainingFile',['../import_data_8c.html#acec4c6a9b1bac910bc6acd76cc3c77b9',1,'importData.c']]],
  ['txt_4',['txt',['../struct_player_mode.html#abeea1413a2ae6c3b17cb7cb859452252',1,'PlayerMode']]]
];
