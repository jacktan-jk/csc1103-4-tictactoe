var searchData=
[
  ['data_0',['data',['../import_data_8c.html#aa07ff3f35da0508c397a5cb0f8376cf8',1,'importData.c']]],
  ['data_5fpath_1',['DATA_PATH',['../import_data_8h.html#ac26a668e32beeb7eae8b6e4adbe5d1e1',1,'importData.h']]],
  ['data_5fsize_2',['DATA_SIZE',['../macros_8h.html#af55149bc1f05cf18af067a302e31e3f9',1,'macros.h']]],
  ['dataset_3',['Dataset',['../struct_dataset.html',1,'']]],
  ['debug_4',['DEBUG',['../macros_8h.html#ad72dbcf6d0153db1b8d8a58001feed83',1,'macros.h']]],
  ['debugdataset_5',['debugDataset',['../ml-naive-bayes_8h.html#a39fc66cfb4519ce0e0840bc766cb79e0',1,'debugDataset(struct Dataset *data, int len):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a39fc66cfb4519ce0e0840bc766cb79e0',1,'debugDataset(struct Dataset *data, int len):&#160;ml-naive-bayes.c']]],
  ['depthcounter_6',['depthCounter',['../minimax_8c.html#aa8d38a95bc17bcaa7a8bb193e84af817',1,'minimax.c']]],
  ['disable_5fasm_7',['DISABLE_ASM',['../macros_8h.html#a5ae05ae4c72cd9ae5147a40a1436cef6',1,'macros.h']]],
  ['disable_5felapsed_8',['DISABLE_ELAPSED',['../macros_8h.html#aacc47b301ed91254362ba4f2cd7efc75',1,'macros.h']]],
  ['disable_5flookup_9',['DISABLE_LOOKUP',['../macros_8h.html#a47dca33d219deb503db9c9d808b24356',1,'macros.h']]],
  ['dobotmove_10',['doBOTmove',['../main_8h.html#af76f1698e679941c21085657b6d98473',1,'doBOTmove():&#160;main.c'],['../main_8c.html#af76f1698e679941c21085657b6d98473',1,'doBOTmove():&#160;main.c']]],
  ['docker_11',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['docker_20image_12',['Docker Image',['../index.html#optional-loading-docker-image',1,'&lt;strong&gt;[OPTIONAL]&lt;/strong&gt; Loading Docker Image'],['../index.html#optional-loading-docker-image-1',1,'&lt;strong&gt;[OPTIONAL]&lt;/strong&gt; Loading Docker Image']]],
  ['docker_20linux_13',['Docker Linux',['../index.html#build-and-run-tictactoe-application-on-docker-linux',1,'Build and Run TicTacToe Application on Docker (Linux)'],['../index.html#building-the-project-via-docker-linux',1,'Building the Project via Docker (Linux)']]],
  ['docker_20macos_14',['Run TicTacToe Application on Docker (MacOS)',['../index.html#run-tictactoe-application-on-docker-macos',1,'']]],
  ['docker_20windows_15',['Docker Windows',['../index.html#build-and-run-tictactoe-application-on-docker-windows',1,'Build and Run TicTacToe Application on Docker (Windows)'],['../index.html#building-the-project-via-docker-windows',1,'Building the Project via Docker (Windows)']]]
];
