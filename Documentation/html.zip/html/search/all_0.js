var searchData=
[
  ['1_20pm_20csc1103_20requirments_20strong_0',['&lt;strong&gt;[^1]PM-CSC1103 REQUIRMENTS&lt;/strong&gt;',['../index.html#autotoc_md1pm-csc1103-requirments',1,'']]]
];
