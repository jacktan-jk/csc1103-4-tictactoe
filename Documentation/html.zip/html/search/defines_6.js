var searchData=
[
  ['play_0',['PLAY',['../macros_8h.html#a34deddb3d2e1791fd7ce5acc13ffc8df',1,'macros.h']]],
  ['player1_1',['PLAYER1',['../macros_8h.html#aff32b2add5186520b5ae86864ebaf51a',1,'macros.h']]],
  ['print_5fdebug_2',['PRINT_DEBUG',['../macros_8h.html#a77496f90d44d7937b09d66c65d23991d',1,'macros.h']]]
];
