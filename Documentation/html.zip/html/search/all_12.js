var searchData=
[
  ['randomno_0',['randomNo',['../import_data_8c.html#a9910e4562c7b65701c5064b4dd6aa203',1,'importData.c']]],
  ['readdataset_1',['readDataset',['../import_data_8h.html#a5129a12fff19bf634c22a38f960e14b3',1,'readDataset(const char *filename, bool split):&#160;importData.c'],['../import_data_8c.html#a5129a12fff19bf634c22a38f960e14b3',1,'readDataset(const char *filename, bool split):&#160;importData.c']]],
  ['readme_2emd_2',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['recommended_20browsers_3a_3',['Recommended Browsers:',['../md__documentation_2_r_e_a_d_m_e.html#recommended-browsers',1,'']]],
  ['requirements_20strong_20both_4',['&lt;strong&gt;BASIC REQUIREMENTS&lt;/strong&gt; (BOTH)',['../index.html#basic-requirements-both',1,'']]],
  ['requirments_20strong_5',['REQUIRMENTS strong',['../index.html#autotoc_md1pm-csc1103-requirments',1,'&lt;strong&gt;[^1]PM-CSC1103 REQUIRMENTS&lt;/strong&gt;'],['../index.html#autotoc_md2coa-csc1104-requirments',1,'&lt;strong&gt;[^2]COA-CSC1104 REQUIRMENTS&lt;/strong&gt;']]],
  ['res_5fpath_6',['RES_PATH',['../import_data_8h.html#a793644bd88146828177a2a4f57e3bf01',1,'importData.h']]],
  ['resettrainingdata_7',['resetTrainingData',['../ml-naive-bayes_8h.html#abf660c40d72d1de487ad5a16a7155d66',1,'resetTrainingData():&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#abf660c40d72d1de487ad5a16a7155d66',1,'resetTrainingData():&#160;ml-naive-bayes.c']]],
  ['row_8',['row',['../struct_position.html#af1d3cff2e4538e23400e260bae3dadad',1,'Position']]],
  ['run_20the_20doxygen_20configuration_20file_20strong_20_3a_9',['1. &lt;strong&gt;Run the Doxygen Configuration File&lt;/strong&gt;:',['../md__documentation_2_r_e_a_d_m_e.html#autotoc_md1-run-the-doxygen-configuration-file',1,'']]],
  ['run_20the_20project_20in_20windows_20w_20o_20docker_10',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['run_20tictactoe_20application_20on_20docker_20linux_11',['Build and Run TicTacToe Application on Docker (Linux)',['../index.html#build-and-run-tictactoe-application-on-docker-linux',1,'']]],
  ['run_20tictactoe_20application_20on_20docker_20macos_12',['Run TicTacToe Application on Docker (MacOS)',['../index.html#run-tictactoe-application-on-docker-macos',1,'']]],
  ['run_20tictactoe_20application_20on_20docker_20windows_13',['Build and Run TicTacToe Application on Docker (Windows)',['../index.html#build-and-run-tictactoe-application-on-docker-windows',1,'']]]
];
