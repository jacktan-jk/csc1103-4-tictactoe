var searchData=
[
  ['updatescorebtn_0',['updateScoreBtn',['../main_8h.html#acc414f6dda9b801014f13c0bf1f14740',1,'updateScoreBtn(gpointer data):&#160;main.c'],['../main_8c.html#acc414f6dda9b801014f13c0bf1f14740',1,'updateScoreBtn(gpointer data):&#160;main.c']]]
];
