var searchData=
[
  ['2_20coa_20csc1104_20requirments_20strong_0',['&lt;strong&gt;[^2]COA-CSC1104 REQUIRMENTS&lt;/strong&gt;',['../index.html#autotoc_md2coa-csc1104-requirments',1,'']]]
];
