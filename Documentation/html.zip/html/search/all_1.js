var searchData=
[
  ['2_20coa_20csc1104_20requirments_20strong_0',['&lt;strong&gt;[^2]COA-CSC1104 REQUIRMENTS&lt;/strong&gt;',['../index.html#autotoc_md2coa-csc1104-requirments',1,'']]],
  ['2_20strong_20view_20the_20html_20documentation_20strong_20_3a_1',['2. &lt;strong&gt;View the HTML Documentation&lt;/strong&gt;:',['../md__documentation_2_r_e_a_d_m_e.html#autotoc_md2-view-the-html-documentation',1,'']]]
];
