var searchData=
[
  ['res_5fpath_0',['RES_PATH',['../import_data_8h.html#a793644bd88146828177a2a4f57e3bf01',1,'importData.h']]]
];
