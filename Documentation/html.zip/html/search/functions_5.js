var searchData=
[
  ['getbestposition_0',['getBestPosition',['../ml-naive-bayes_8h.html#adb6b2fbadefdff0ed94d6ef2e0ef176c',1,'getBestPosition(int grid[3][3], char player):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#adb6b2fbadefdff0ed94d6ef2e0ef176c',1,'getBestPosition(int grid[3][3], char player):&#160;ml-naive-bayes.c']]],
  ['getrandomno_1',['getRandomNo',['../import_data_8h.html#a516cae4e8116d0b4b9268cd6768487f6',1,'getRandomNo(int random[DATA_SIZE]):&#160;importData.c'],['../import_data_8c.html#a516cae4e8116d0b4b9268cd6768487f6',1,'getRandomNo(int random[DATA_SIZE]):&#160;importData.c']]],
  ['gettestingdata_2',['getTestingData',['../import_data_8h.html#af70ae09f2665c0a3de0a14322fe4b107',1,'getTestingData(struct Dataset **d):&#160;importData.c'],['../import_data_8c.html#af70ae09f2665c0a3de0a14322fe4b107',1,'getTestingData(struct Dataset **d):&#160;importData.c']]],
  ['gettrainingdata_3',['getTrainingData',['../import_data_8h.html#a4ee672f09716ad82ade7b665d807b07a',1,'getTrainingData(struct Dataset **d):&#160;importData.c'],['../import_data_8c.html#a4ee672f09716ad82ade7b665d807b07a',1,'getTrainingData(struct Dataset **d):&#160;importData.c']]],
  ['gettruthvalue_4',['getTruthValue',['../ml-naive-bayes_8h.html#ae6c5693fa5f2aef85092855a1a83ba08',1,'getTruthValue(char *str1):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#ae6c5693fa5f2aef85092855a1a83ba08',1,'getTruthValue(char *str1):&#160;ml-naive-bayes.c']]]
];
