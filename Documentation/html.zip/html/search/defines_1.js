var searchData=
[
  ['classes_0',['CLASSES',['../macros_8h.html#aa6df04fbcd3d2e5765447931df2c3d19',1,'CLASSES:&#160;macros.h'],['../ml-naive-bayes_8h.html#aa6df04fbcd3d2e5765447931df2c3d19',1,'CLASSES:&#160;ml-naive-bayes.h']]]
];
