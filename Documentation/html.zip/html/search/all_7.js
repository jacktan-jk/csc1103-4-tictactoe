var searchData=
[
  ['file_5fbestmov_0',['FILE_BESTMOV',['../minimax_8h.html#a639effcb37d2b98906303fecdb9c9f5e',1,'minimax.h']]],
  ['findbestmove_1',['findBestMove',['../minimax_8h.html#a0efa6e5041878576ac8e039fab89e046',1,'findBestMove(int board[3][3]):&#160;minimax.c'],['../minimax_8c.html#a0efa6e5041878576ac8e039fab89e046',1,'findBestMove(int board[3][3]):&#160;minimax.c']]]
];
