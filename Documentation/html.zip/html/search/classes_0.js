var searchData=
[
  ['boardstate_0',['BoardState',['../struct_board_state.html',1,'']]],
  ['btnpos_1',['BtnPos',['../struct_btn_pos.html',1,'']]]
];
