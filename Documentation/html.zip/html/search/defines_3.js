var searchData=
[
  ['empty_0',['EMPTY',['../macros_8h.html#a2b7cf2a3641be7b89138615764d60ba3',1,'macros.h']]],
  ['error_1',['ERROR',['../macros_8h.html#a8fe83ac76edc595f6b98cd4a4127aed5',1,'macros.h']]]
];
