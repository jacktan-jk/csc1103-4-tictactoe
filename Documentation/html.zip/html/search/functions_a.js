var searchData=
[
  ['predictoutcome_0',['predictOutcome',['../ml-naive-bayes_8h.html#a47ee49cedcea70023c8789c6431b67e6',1,'predictOutcome(struct Dataset board):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a47ee49cedcea70023c8789c6431b67e6',1,'predictOutcome(struct Dataset board):&#160;ml-naive-bayes.c']]],
  ['printfilecontents_1',['printFileContents',['../minimax_8h.html#aebb81db22ed3bba673d41fef99ffc9fd',1,'minimax.h']]]
];
