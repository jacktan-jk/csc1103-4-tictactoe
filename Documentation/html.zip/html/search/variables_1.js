var searchData=
[
  ['bestmove_0',['bestMove',['../struct_board_state.html#abac4e5d9337901878b415c9fa72160a7',1,'BoardState']]],
  ['board_1',['board',['../struct_board_state.html#a57b9f8c3a06f5141eea6b5d22c4c4eb9',1,'BoardState']]],
  ['btngrid_2',['btnGrid',['../main_8c.html#a7deca23032284da0ca814198f21f592c',1,'main.c']]]
];
