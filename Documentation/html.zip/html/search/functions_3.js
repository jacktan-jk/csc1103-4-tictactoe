var searchData=
[
  ['evaluate_0',['evaluate',['../minimax_8h.html#a7eb0ef2ef587e3148bc0811943f7ec13',1,'evaluate(int b[3][3]):&#160;minimax.c'],['../minimax_8c.html#a7eb0ef2ef587e3148bc0811943f7ec13',1,'evaluate(int b[3][3]):&#160;minimax.c']]]
];
