var searchData=
[
  ['o_20docker_0',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['on_20docker_20linux_1',['Build and Run TicTacToe Application on Docker (Linux)',['../index.html#build-and-run-tictactoe-application-on-docker-linux',1,'']]],
  ['on_20docker_20macos_2',['Run TicTacToe Application on Docker (MacOS)',['../index.html#run-tictactoe-application-on-docker-macos',1,'']]],
  ['on_20docker_20windows_3',['Build and Run TicTacToe Application on Docker (Windows)',['../index.html#build-and-run-tictactoe-application-on-docker-windows',1,'']]],
  ['on_5fbtngrid_5fclicked_4',['on_btnGrid_clicked',['../main_8h.html#a20666861ea3282632824204e33c1411a',1,'on_btnGrid_clicked(GtkWidget *widget, gpointer data):&#160;main.c'],['../main_8c.html#a20666861ea3282632824204e33c1411a',1,'on_btnGrid_clicked(GtkWidget *widget, gpointer data):&#160;main.c']]],
  ['on_5fbtnscore_5fclicked_5',['on_btnScore_clicked',['../main_8h.html#a771f6ad36f989d0b7d43aa9a6eea439f',1,'on_btnScore_clicked(GtkWidget *widget, gpointer data):&#160;main.c'],['../main_8c.html#a771f6ad36f989d0b7d43aa9a6eea439f',1,'on_btnScore_clicked(GtkWidget *widget, gpointer data):&#160;main.c']]],
  ['optional_20strong_20loading_20docker_20image_6',['OPTIONAL strong Loading Docker Image',['../index.html#optional-loading-docker-image',1,'&lt;strong&gt;[OPTIONAL]&lt;/strong&gt; Loading Docker Image'],['../index.html#optional-loading-docker-image-1',1,'&lt;strong&gt;[OPTIONAL]&lt;/strong&gt; Loading Docker Image']]],
  ['outcome_7',['outcome',['../struct_dataset.html#a207163fc7e81ca487088a1f8ad958a89',1,'Dataset']]]
];
