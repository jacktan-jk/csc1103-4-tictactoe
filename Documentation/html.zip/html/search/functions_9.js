var searchData=
[
  ['on_5fbtngrid_5fclicked_0',['on_btnGrid_clicked',['../main_8h.html#a20666861ea3282632824204e33c1411a',1,'on_btnGrid_clicked(GtkWidget *widget, gpointer data):&#160;main.c'],['../main_8c.html#a20666861ea3282632824204e33c1411a',1,'on_btnGrid_clicked(GtkWidget *widget, gpointer data):&#160;main.c']]],
  ['on_5fbtnscore_5fclicked_1',['on_btnScore_clicked',['../main_8h.html#a771f6ad36f989d0b7d43aa9a6eea439f',1,'on_btnScore_clicked(GtkWidget *widget, gpointer data):&#160;main.c'],['../main_8c.html#a771f6ad36f989d0b7d43aa9a6eea439f',1,'on_btnScore_clicked(GtkWidget *widget, gpointer data):&#160;main.c']]]
];
