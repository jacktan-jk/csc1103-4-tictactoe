var searchData=
[
  ['len_5ftest_0',['len_test',['../import_data_8c.html#a360429d88170e85d0a61d259c5e7e90b',1,'importData.c']]],
  ['len_5ftrain_1',['len_train',['../import_data_8c.html#aa6645f60309558a04b334bf63be092b1',1,'importData.c']]]
];
