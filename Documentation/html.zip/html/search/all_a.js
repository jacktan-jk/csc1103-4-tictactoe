var searchData=
[
  ['gendtime_0',['gEndTime',['../elapsed_time_8c.html#a054f99abaccc2b31249ff43baa70178a',1,'elapsedTime.c']]],
  ['generate_20and_20view_20latex_20documentation_20strong_20_3a_1',['3. &lt;strong&gt;Generate and View LaTeX Documentation&lt;/strong&gt;:',['../md__documentation_2_r_e_a_d_m_e.html#autotoc_md3-generate-and-view-latex-documentation',1,'']]],
  ['generate_20and_20view_20the_20documentation_3a_2',['Steps to Generate and View the Documentation:',['../md__documentation_2_r_e_a_d_m_e.html#steps-to-generate-and-view-the-documentation',1,'']]],
  ['generation_20and_20viewing_20instructions_3',['Doxygen Documentation Generation and Viewing Instructions',['../md__documentation_2_r_e_a_d_m_e.html',1,'']]],
  ['getbestposition_4',['getBestPosition',['../ml-naive-bayes_8h.html#adb6b2fbadefdff0ed94d6ef2e0ef176c',1,'getBestPosition(int grid[3][3], char player):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#adb6b2fbadefdff0ed94d6ef2e0ef176c',1,'getBestPosition(int grid[3][3], char player):&#160;ml-naive-bayes.c']]],
  ['getrandomno_5',['getRandomNo',['../import_data_8h.html#a516cae4e8116d0b4b9268cd6768487f6',1,'getRandomNo(int random[DATA_SIZE]):&#160;importData.c'],['../import_data_8c.html#a516cae4e8116d0b4b9268cd6768487f6',1,'getRandomNo(int random[DATA_SIZE]):&#160;importData.c']]],
  ['gettestingdata_6',['getTestingData',['../import_data_8h.html#af70ae09f2665c0a3de0a14322fe4b107',1,'getTestingData(struct Dataset **d):&#160;importData.c'],['../import_data_8c.html#af70ae09f2665c0a3de0a14322fe4b107',1,'getTestingData(struct Dataset **d):&#160;importData.c']]],
  ['gettrainingdata_7',['getTrainingData',['../import_data_8h.html#a4ee672f09716ad82ade7b665d807b07a',1,'getTrainingData(struct Dataset **d):&#160;importData.c'],['../import_data_8c.html#a4ee672f09716ad82ade7b665d807b07a',1,'getTrainingData(struct Dataset **d):&#160;importData.c']]],
  ['gettruthvalue_8',['getTruthValue',['../ml-naive-bayes_8h.html#ae6c5693fa5f2aef85092855a1a83ba08',1,'getTruthValue(char *str1):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#ae6c5693fa5f2aef85092855a1a83ba08',1,'getTruthValue(char *str1):&#160;ml-naive-bayes.c']]],
  ['grid_9',['grid',['../struct_dataset.html#afda761d4a86b83805f114e9c7aae1fc6',1,'Dataset']]],
  ['gstarttime_10',['gStartTime',['../elapsed_time_8c.html#a61fb098c017b802b555f83d742816bc8',1,'elapsedTime.c']]],
  ['gtime_11',['gTime',['../elapsed_time_8c.html#a8e01bb9ba881b8bf6d296be8d588b3c6',1,'elapsedTime.c']]]
];
