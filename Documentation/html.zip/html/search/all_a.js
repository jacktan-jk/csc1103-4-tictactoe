var searchData=
[
  ['len_5ftest_0',['len_test',['../import_data_8c.html#a360429d88170e85d0a61d259c5e7e90b',1,'importData.c']]],
  ['len_5ftrain_1',['len_train',['../import_data_8c.html#aa6645f60309558a04b334bf63be092b1',1,'importData.c']]],
  ['linux_2',['Linux',['../index.html#build-and-run-tictactoe-application-on-docker-linux',1,'Build and Run TicTacToe Application on Docker (Linux)'],['../index.html#building-the-project-via-docker-linux',1,'Building the Project via Docker (Linux)'],['../index.html#installation-instructions-linux',1,'Installation Instructions (Linux)']]],
  ['loadboardstates_3',['loadBoardStates',['../minimax_8h.html#ad96b1cb65a3cf3189660045f9351e66b',1,'loadBoardStates(struct BoardState boardStates[]):&#160;minimax.c'],['../minimax_8c.html#ad96b1cb65a3cf3189660045f9351e66b',1,'loadBoardStates(struct BoardState boardStates[]):&#160;minimax.c']]],
  ['loading_20docker_20image_4',['Loading Docker Image',['../index.html#optional-loading-docker-image',1,'&lt;strong&gt;[OPTIONAL]&lt;/strong&gt; Loading Docker Image'],['../index.html#optional-loading-docker-image-1',1,'&lt;strong&gt;[OPTIONAL]&lt;/strong&gt; Loading Docker Image']]]
];
