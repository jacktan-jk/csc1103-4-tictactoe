var searchData=
[
  ['max_5fboards_0',['MAX_BOARDS',['../minimax_8h.html#a09d570e408c9e6ed66026c7ae5713473',1,'minimax.h']]],
  ['minimax_5fgodmode_1',['MINIMAX_GODMODE',['../macros_8h.html#a0223dfa64002c42b357e8f4f46dc139f',1,'macros.h']]],
  ['mode_5f2p_2',['MODE_2P',['../macros_8h.html#a733c98a18575d60db109addf4efa956a',1,'macros.h']]],
  ['mode_5fml_3',['MODE_ML',['../macros_8h.html#ad6f35c3ff19e8e5cf4d8e4859e3240d1',1,'macros.h']]],
  ['mode_5fmm_4',['MODE_MM',['../macros_8h.html#a86d9cfb06869d7709dbdcfd5c0515e90',1,'macros.h']]]
];
