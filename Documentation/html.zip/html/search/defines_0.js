var searchData=
[
  ['bad_5fparam_0',['BAD_PARAM',['../macros_8h.html#adb25c89db5336fcc8b27359a183a6daa',1,'macros.h']]],
  ['bot_1',['BOT',['../macros_8h.html#a8729a567b846ff767c1fbf87fd5725e8',1,'macros.h']]]
];
