var searchData=
[
  ['actual_0',['actual',['../ml-naive-bayes_8c.html#ab45b5270856ae9a7c5869af590e53e18',1,'ml-naive-bayes.c']]],
  ['and_20run_20the_20project_20in_20windows_20w_20o_20docker_1',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['and_20run_20tictactoe_20application_20on_20docker_20linux_2',['Build and Run TicTacToe Application on Docker (Linux)',['../index.html#build-and-run-tictactoe-application-on-docker-linux',1,'']]],
  ['and_20run_20tictactoe_20application_20on_20docker_20windows_3',['Build and Run TicTacToe Application on Docker (Windows)',['../index.html#build-and-run-tictactoe-application-on-docker-windows',1,'']]],
  ['and_20view_20latex_20documentation_20strong_20_3a_4',['3. &lt;strong&gt;Generate and View LaTeX Documentation&lt;/strong&gt;:',['../md__documentation_2_r_e_a_d_m_e.html#autotoc_md3-generate-and-view-latex-documentation',1,'']]],
  ['and_20view_20the_20documentation_3a_5',['Steps to Generate and View the Documentation:',['../md__documentation_2_r_e_a_d_m_e.html#steps-to-generate-and-view-the-documentation',1,'']]],
  ['and_20viewing_20instructions_6',['Doxygen Documentation Generation and Viewing Instructions',['../md__documentation_2_r_e_a_d_m_e.html',1,'']]],
  ['application_20on_20docker_20linux_7',['Build and Run TicTacToe Application on Docker (Linux)',['../index.html#build-and-run-tictactoe-application-on-docker-linux',1,'']]],
  ['application_20on_20docker_20macos_8',['Run TicTacToe Application on Docker (MacOS)',['../index.html#run-tictactoe-application-on-docker-macos',1,'']]],
  ['application_20on_20docker_20windows_9',['Build and Run TicTacToe Application on Docker (Windows)',['../index.html#build-and-run-tictactoe-application-on-docker-windows',1,'']]],
  ['assigncmvalue_10',['assignCMValue',['../ml-naive-bayes_8h.html#ad2a4ca79d29276c99f36cc583b47c6c3',1,'assignCMValue(int actual, int predicted):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#ad2a4ca79d29276c99f36cc583b47c6c3',1,'assignCMValue(int actual, int predicted):&#160;ml-naive-bayes.c']]],
  ['assignmoveindex_11',['assignMoveIndex',['../ml-naive-bayes_8h.html#a50b257da463de74ba2358056e85342ff',1,'assignMoveIndex(char move):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a50b257da463de74ba2358056e85342ff',1,'assignMoveIndex(char move):&#160;ml-naive-bayes.c']]]
];
