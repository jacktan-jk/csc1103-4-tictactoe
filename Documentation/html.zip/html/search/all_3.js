var searchData=
[
  ['bad_5fparam_0',['BAD_PARAM',['../macros_8h.html#adb25c89db5336fcc8b27359a183a6daa',1,'macros.h']]],
  ['basic_20requirements_20strong_20both_1',['&lt;strong&gt;BASIC REQUIREMENTS&lt;/strong&gt; (BOTH)',['../index.html#basic-requirements-both',1,'']]],
  ['bestmove_2',['bestMove',['../struct_board_state.html#abac4e5d9337901878b415c9fa72160a7',1,'BoardState']]],
  ['board_3',['board',['../struct_board_state.html#a57b9f8c3a06f5141eea6b5d22c4c4eb9',1,'BoardState']]],
  ['boardstate_4',['BoardState',['../struct_board_state.html',1,'']]],
  ['bot_5',['BOT',['../macros_8h.html#a8729a567b846ff767c1fbf87fd5725e8',1,'macros.h']]],
  ['both_6',['&lt;strong&gt;BASIC REQUIREMENTS&lt;/strong&gt; (BOTH)',['../index.html#basic-requirements-both',1,'']]],
  ['btngrid_7',['btnGrid',['../main_8c.html#a7deca23032284da0ca814198f21f592c',1,'main.c']]],
  ['btnpos_8',['BtnPos',['../struct_btn_pos.html',1,'']]],
  ['build_20and_20run_20the_20project_20in_20windows_20w_20o_20docker_9',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['build_20and_20run_20tictactoe_20application_20on_20docker_20linux_10',['Build and Run TicTacToe Application on Docker (Linux)',['../index.html#build-and-run-tictactoe-application-on-docker-linux',1,'']]],
  ['build_20and_20run_20tictactoe_20application_20on_20docker_20windows_11',['Build and Run TicTacToe Application on Docker (Windows)',['../index.html#build-and-run-tictactoe-application-on-docker-windows',1,'']]],
  ['building_20the_20project_20via_20docker_20linux_12',['Building the Project via Docker (Linux)',['../index.html#building-the-project-via-docker-linux',1,'']]],
  ['building_20the_20project_20via_20docker_20windows_13',['Building the Project via Docker (Windows)',['../index.html#building-the-project-via-docker-windows',1,'']]]
];
