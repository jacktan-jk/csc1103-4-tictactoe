var searchData=
[
  ['w_20o_20docker_0',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['win_1',['WIN',['../macros_8h.html#a43105771f16e2da3078149f0de528e9b',1,'macros.h']]],
  ['windows_2',['Windows',['../index.html#build-and-run-tictactoe-application-on-docker-windows',1,'Build and Run TicTacToe Application on Docker (Windows)'],['../index.html#building-the-project-via-docker-windows',1,'Building the Project via Docker (Windows)'],['../index.html#installation-instructions-windows',1,'Installation Instructions (Windows)']]],
  ['windows_20w_20o_20docker_3',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['writebestmovetofile_4',['writeBestMoveToFile',['../minimax_8h.html#a887a1c4feb6adb0ec61b30ced51619eb',1,'writeBestMoveToFile(int board[3][3], struct Position bestMove):&#160;minimax.c'],['../minimax_8c.html#a887a1c4feb6adb0ec61b30ced51619eb',1,'writeBestMoveToFile(int board[3][3], struct Position bestMove):&#160;minimax.c']]]
];
