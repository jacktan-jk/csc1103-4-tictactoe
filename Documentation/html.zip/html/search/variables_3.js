var searchData=
[
  ['data_0',['data',['../import_data_8c.html#aa07ff3f35da0508c397a5cb0f8376cf8',1,'importData.c']]],
  ['depthcounter_1',['depthCounter',['../minimax_8c.html#aa8d38a95bc17bcaa7a8bb193e84af817',1,'minimax.c']]]
];
