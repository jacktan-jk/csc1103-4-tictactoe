var searchData=
[
  ['play_0',['PLAY',['../macros_8h.html#a34deddb3d2e1791fd7ce5acc13ffc8df',1,'macros.h']]],
  ['player1_1',['PLAYER1',['../macros_8h.html#aff32b2add5186520b5ae86864ebaf51a',1,'macros.h']]],
  ['playermode_2',['PlayerMode',['../struct_player_mode.html',1,'']]],
  ['playermode_3',['playerMode',['../main_8c.html#a5e71fc65a887b894007f895ddcd5831e',1,'main.c']]],
  ['pm_20csc1103_20requirments_20strong_4',['&lt;strong&gt;[^1]PM-CSC1103 REQUIRMENTS&lt;/strong&gt;',['../index.html#autotoc_md1pm-csc1103-requirments',1,'']]],
  ['pos_5',['pos',['../struct_btn_pos.html#a48115af1066a06f5f7b9f9290682d30a',1,'BtnPos']]],
  ['position_6',['Position',['../struct_position.html',1,'']]],
  ['positive_5fcount_7',['positive_count',['../ml-naive-bayes_8c.html#ad96f4ddc585e3bc1b86741606ac56b4a',1,'ml-naive-bayes.c']]],
  ['positiveclassprobability_8',['positiveClassProbability',['../ml-naive-bayes_8c.html#a12bf5ea2077e1f91b0d673f5db01a9ea',1,'ml-naive-bayes.c']]],
  ['positivemovecount_9',['positiveMoveCount',['../ml-naive-bayes_8c.html#a4eae19039f06c5a80b6afc74704a1233',1,'ml-naive-bayes.c']]],
  ['predicted_10',['predicted',['../ml-naive-bayes_8c.html#a9950a0cdc9cadbb3ae60eaade29de140',1,'ml-naive-bayes.c']]],
  ['predictoutcome_11',['predictOutcome',['../ml-naive-bayes_8h.html#a47ee49cedcea70023c8789c6431b67e6',1,'predictOutcome(struct Dataset board):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a47ee49cedcea70023c8789c6431b67e6',1,'predictOutcome(struct Dataset board):&#160;ml-naive-bayes.c']]],
  ['print_5fdebug_12',['PRINT_DEBUG',['../macros_8h.html#a77496f90d44d7937b09d66c65d23991d',1,'macros.h']]],
  ['printfilecontents_13',['printFileContents',['../minimax_8h.html#aebb81db22ed3bba673d41fef99ffc9fd',1,'minimax.h']]],
  ['probabilityerrors_14',['probabilityErrors',['../ml-naive-bayes_8c.html#a2c231c801fe9098999dbc7e941e871fb',1,'ml-naive-bayes.c']]],
  ['project_20in_20windows_20w_20o_20docker_15',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['project_20strong_16',['&lt;strong&gt;TIC TAC TOE - CSC1103 &amp; CSC1104 Project&lt;/strong&gt;',['../index.html#tic-tac-toe---csc1103--csc1104-project',1,'']]],
  ['project_20via_20docker_20linux_17',['Building the Project via Docker (Linux)',['../index.html#building-the-project-via-docker-linux',1,'']]],
  ['project_20via_20docker_20windows_18',['Building the Project via Docker (Windows)',['../index.html#building-the-project-via-docker-windows',1,'']]]
];
