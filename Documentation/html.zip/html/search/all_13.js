var searchData=
[
  ['via_20docker_20linux_0',['Building the Project via Docker (Linux)',['../index.html#building-the-project-via-docker-linux',1,'']]],
  ['via_20docker_20windows_1',['Building the Project via Docker (Windows)',['../index.html#building-the-project-via-docker-windows',1,'']]]
];
