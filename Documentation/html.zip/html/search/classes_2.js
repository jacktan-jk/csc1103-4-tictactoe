var searchData=
[
  ['playermode_0',['PlayerMode',['../struct_player_mode.html',1,'']]],
  ['position_1',['Position',['../struct_position.html',1,'']]]
];
