var searchData=
[
  ['initdata_0',['initData',['../ml-naive-bayes_8h.html#a1d519f1ac761ee87a5de63ff461958ca',1,'initData():&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a1d519f1ac761ee87a5de63ff461958ca',1,'initData():&#160;ml-naive-bayes.c']]],
  ['ismovesleft_1',['isMovesLeft',['../minimax_8h.html#a3df458be79a64addf900a0dda94ae53d',1,'isMovesLeft(int board[3][3]):&#160;minimax.c'],['../minimax_8c.html#a3df458be79a64addf900a0dda94ae53d',1,'isMovesLeft(int board[3][3]):&#160;minimax.c']]]
];
