var searchData=
[
  ['test_5fpath_0',['TEST_PATH',['../import_data_8h.html#a5966a44df244da9e3b2aab95cb69adc1',1,'importData.h']]],
  ['testing_5fdata_5fsize_1',['TESTING_DATA_SIZE',['../ml-naive-bayes_8h.html#a5f4f4db0f77efc9e06b59f3574a93818',1,'ml-naive-bayes.h']]],
  ['tie_2',['TIE',['../macros_8h.html#a047b752526fa845a214fbd2dda59bdaa',1,'macros.h']]],
  ['train_5fpath_3',['TRAIN_PATH',['../import_data_8h.html#ae0d3caefdba95baf2009a1db6d4d5380',1,'importData.h']]],
  ['training_5fdata_5fsize_4',['TRAINING_DATA_SIZE',['../ml-naive-bayes_8h.html#a3b72bac4ef32b693683e40a632c40acf',1,'ml-naive-bayes.h']]]
];
