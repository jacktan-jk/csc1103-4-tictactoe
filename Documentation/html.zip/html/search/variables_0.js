var searchData=
[
  ['actual_0',['actual',['../ml-naive-bayes_8c.html#ab45b5270856ae9a7c5869af590e53e18',1,'ml-naive-bayes.c']]]
];
