var searchData=
[
  ['win_0',['WIN',['../macros_8h.html#a43105771f16e2da3078149f0de528e9b',1,'macros.h']]]
];
