var searchData=
[
  ['iboard_0',['iBoard',['../main_8c.html#adc21ea5cc28327a21455788fa1b9518f',1,'main.c']]],
  ['igamestate_1',['iGameState',['../main_8c.html#a80fa44672f562631d6347fc01e0c9a8a',1,'main.c']]],
  ['image_2',['Image',['../index.html#optional-loading-docker-image',1,'&lt;strong&gt;[OPTIONAL]&lt;/strong&gt; Loading Docker Image'],['../index.html#optional-loading-docker-image-1',1,'&lt;strong&gt;[OPTIONAL]&lt;/strong&gt; Loading Docker Image']]],
  ['importdata_2ec_3',['importData.c',['../import_data_8c.html',1,'']]],
  ['importdata_2eh_4',['importData.h',['../import_data_8h.html',1,'']]],
  ['in_20windows_20w_20o_20docker_5',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['initdata_6',['initData',['../ml-naive-bayes_8h.html#a1d519f1ac761ee87a5de63ff461958ca',1,'initData():&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a1d519f1ac761ee87a5de63ff461958ca',1,'initData():&#160;ml-naive-bayes.c']]],
  ['installation_20instructions_20linux_7',['Installation Instructions (Linux)',['../index.html#installation-instructions-linux',1,'']]],
  ['installation_20instructions_20macos_8',['Installation Instructions (MacOS)',['../index.html#installation-instructions-macos',1,'']]],
  ['installation_20instructions_20windows_9',['Installation Instructions (Windows)',['../index.html#installation-instructions-windows',1,'']]],
  ['instructions_10',['Doxygen Documentation Generation and Viewing Instructions',['../md__documentation_2_r_e_a_d_m_e.html',1,'']]],
  ['instructions_20linux_11',['Installation Instructions (Linux)',['../index.html#installation-instructions-linux',1,'']]],
  ['instructions_20macos_12',['Installation Instructions (MacOS)',['../index.html#installation-instructions-macos',1,'']]],
  ['instructions_20windows_13',['Installation Instructions (Windows)',['../index.html#installation-instructions-windows',1,'']]],
  ['iplayer1_5fscore_14',['iPlayer1_score',['../main_8c.html#ae1d310ad434c7a2f6b36903df0e48f7f',1,'main.c']]],
  ['iplayer2_5fscore_15',['iPlayer2_score',['../main_8c.html#a8ef9076ab0a4dabeb8638b2295ccd7e8',1,'main.c']]],
  ['ismlavail_16',['isMLAvail',['../main_8c.html#a3b5a2ec67eaad775b0eedc6c869b0efa',1,'main.c']]],
  ['ismovesleft_17',['isMovesLeft',['../minimax_8h.html#a3df458be79a64addf900a0dda94ae53d',1,'isMovesLeft(int board[3][3]):&#160;minimax.c'],['../minimax_8c.html#a3df458be79a64addf900a0dda94ae53d',1,'isMovesLeft(int board[3][3]):&#160;minimax.c']]],
  ['isplayer1turn_18',['isPlayer1Turn',['../main_8c.html#ac7d33f5c85beb77a9f9b399811ee34c6',1,'main.c']]],
  ['itie_5fscore_19',['iTie_score',['../main_8c.html#a95f308163088cd3cc0aee84261b02030',1,'main.c']]],
  ['iwinpos_20',['iWinPos',['../main_8c.html#a300a754c6a50ee6fc5e78bd8caf55f3b',1,'main.c']]]
];
