var searchData=
[
  ['calcconfusionmatrix_0',['calcConfusionMatrix',['../ml-naive-bayes_8h.html#a0994d944dcdbc157e60c5b96a2c27fdf',1,'calcConfusionMatrix():&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a0994d944dcdbc157e60c5b96a2c27fdf',1,'calcConfusionMatrix():&#160;ml-naive-bayes.c']]],
  ['calctrainerrors_1',['calcTrainErrors',['../ml-naive-bayes_8h.html#a4d2eddd8e919b0f28a86c5d0f820a269',1,'calcTrainErrors():&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a4d2eddd8e919b0f28a86c5d0f820a269',1,'calcTrainErrors():&#160;ml-naive-bayes.c']]],
  ['calculateprobabilities_2',['calculateProbabilities',['../ml-naive-bayes_8h.html#a112adbcfbb6027bb85c8150c15c3d98b',1,'calculateProbabilities(int dataset_size):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a112adbcfbb6027bb85c8150c15c3d98b',1,'calculateProbabilities(int dataset_size):&#160;ml-naive-bayes.c']]],
  ['checkandupdatebestmove_3',['checkAndUpdateBestMove',['../minimax_8h.html#a877aa8e7e6b5f77be1c8b5990e5d1625',1,'checkAndUpdateBestMove(int board[3][3], struct Position *bestMove, struct BoardState boardStates[], int count):&#160;minimax.c'],['../minimax_8c.html#a877aa8e7e6b5f77be1c8b5990e5d1625',1,'checkAndUpdateBestMove(int board[3][3], struct Position *bestMove, struct BoardState boardStates[], int count):&#160;minimax.c']]],
  ['chkplayerwin_4',['chkPlayerWin',['../main_8h.html#ab3744385ac07502d3920342e20805ec7',1,'chkPlayerWin():&#160;main.c'],['../main_8c.html#ab3744385ac07502d3920342e20805ec7',1,'chkPlayerWin():&#160;main.c']]],
  ['cleargrid_5',['clearGrid',['../main_8h.html#ad28c8c932b46ed4bce19748ba7106599',1,'clearGrid():&#160;main.c'],['../main_8c.html#ad28c8c932b46ed4bce19748ba7106599',1,'clearGrid():&#160;main.c']]]
];
