var searchData=
[
  ['tac_20toe_20csc1103_20csc1104_20project_20strong_0',['&lt;strong&gt;TIC TAC TOE - CSC1103 &amp; CSC1104 Project&lt;/strong&gt;',['../index.html#tic-tac-toe---csc1103--csc1104-project',1,'']]],
  ['test_5fpath_1',['TEST_PATH',['../import_data_8h.html#a5966a44df244da9e3b2aab95cb69adc1',1,'importData.h']]],
  ['test_5fpredictederrors_2',['test_PredictedErrors',['../ml-naive-bayes_8c.html#af1bf8dd0e4f0e05e4360bcabd1b2da89',1,'ml-naive-bayes.c']]],
  ['testing_5fdata_5fsize_3',['TESTING_DATA_SIZE',['../ml-naive-bayes_8h.html#a5f4f4db0f77efc9e06b59f3574a93818',1,'ml-naive-bayes.h']]],
  ['testingfile_4',['testingFile',['../import_data_8c.html#a372bb3912d20ff92d4ac1b566a824fc4',1,'importData.c']]],
  ['the_20project_20in_20windows_20w_20o_20docker_5',['Build and Run the Project in Windows (w/o Docker)',['../index.html#build-and-run-the-project-in-windows-wo-docker',1,'']]],
  ['the_20project_20via_20docker_20linux_6',['Building the Project via Docker (Linux)',['../index.html#building-the-project-via-docker-linux',1,'']]],
  ['the_20project_20via_20docker_20windows_7',['Building the Project via Docker (Windows)',['../index.html#building-the-project-via-docker-windows',1,'']]],
  ['tic_20tac_20toe_20csc1103_20csc1104_20project_20strong_8',['&lt;strong&gt;TIC TAC TOE - CSC1103 &amp; CSC1104 Project&lt;/strong&gt;',['../index.html#tic-tac-toe---csc1103--csc1104-project',1,'']]],
  ['tictactoe_9',['TicTacToe',['../index.html',1,'']]],
  ['tictactoe_20application_20on_20docker_20linux_10',['Build and Run TicTacToe Application on Docker (Linux)',['../index.html#build-and-run-tictactoe-application-on-docker-linux',1,'']]],
  ['tictactoe_20application_20on_20docker_20macos_11',['Run TicTacToe Application on Docker (MacOS)',['../index.html#run-tictactoe-application-on-docker-macos',1,'']]],
  ['tictactoe_20application_20on_20docker_20windows_12',['Build and Run TicTacToe Application on Docker (Windows)',['../index.html#build-and-run-tictactoe-application-on-docker-windows',1,'']]],
  ['tie_13',['TIE',['../macros_8h.html#a047b752526fa845a214fbd2dda59bdaa',1,'macros.h']]],
  ['toe_20csc1103_20csc1104_20project_20strong_14',['&lt;strong&gt;TIC TAC TOE - CSC1103 &amp; CSC1104 Project&lt;/strong&gt;',['../index.html#tic-tac-toe---csc1103--csc1104-project',1,'']]],
  ['train_5fpath_15',['TRAIN_PATH',['../import_data_8h.html#ae0d3caefdba95baf2009a1db6d4d5380',1,'importData.h']]],
  ['train_5fpredictederrors_16',['train_PredictedErrors',['../ml-naive-bayes_8c.html#ad6914c7200a9bef056b87f9ffec33e82',1,'ml-naive-bayes.c']]],
  ['training_5fdata_5fsize_17',['TRAINING_DATA_SIZE',['../ml-naive-bayes_8h.html#a3b72bac4ef32b693683e40a632c40acf',1,'ml-naive-bayes.h']]],
  ['trainingfile_18',['trainingFile',['../import_data_8c.html#acec4c6a9b1bac910bc6acd76cc3c77b9',1,'importData.c']]],
  ['txt_19',['txt',['../struct_player_mode.html#abeea1413a2ae6c3b17cb7cb859452252',1,'PlayerMode']]]
];
