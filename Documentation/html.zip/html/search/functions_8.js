var searchData=
[
  ['main_0',['main',['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.c']]],
  ['max_1',['max',['../minimax_8h.html#af082905f7eac6d03e92015146bbc1925',1,'max(int a, int b):&#160;minimax.c'],['../minimax_8c.html#af082905f7eac6d03e92015146bbc1925',1,'max(int a, int b):&#160;minimax.c']]],
  ['min_2',['min',['../minimax_8h.html#abd8bbcfabb3ddef2ccaafb9928a37b95',1,'min(int a, int b):&#160;minimax.c'],['../minimax_8c.html#abd8bbcfabb3ddef2ccaafb9928a37b95',1,'min(int a, int b):&#160;minimax.c']]],
  ['minimax_3',['minimax',['../minimax_8h.html#a5f4a74701aaef2a7cae76669feeea456',1,'minimax(int board[3][3], int depth, bool isMax):&#160;minimax.c'],['../minimax_8c.html#a5f4a74701aaef2a7cae76669feeea456',1,'minimax(int board[3][3], int depth, bool isMax):&#160;minimax.c']]]
];
