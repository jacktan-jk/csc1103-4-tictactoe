var searchData=
[
  ['file_20strong_20_3a_0',['1. &lt;strong&gt;Run the Doxygen Configuration File&lt;/strong&gt;:',['../md__documentation_2_r_e_a_d_m_e.html#autotoc_md1-run-the-doxygen-configuration-file',1,'']]],
  ['file_5fbestmov_1',['FILE_BESTMOV',['../minimax_8h.html#a639effcb37d2b98906303fecdb9c9f5e',1,'minimax.h']]],
  ['findbestmove_2',['findBestMove',['../minimax_8h.html#a0efa6e5041878576ac8e039fab89e046',1,'findBestMove(int board[3][3]):&#160;minimax.c'],['../minimax_8c.html#a0efa6e5041878576ac8e039fab89e046',1,'findBestMove(int board[3][3]):&#160;minimax.c']]]
];
