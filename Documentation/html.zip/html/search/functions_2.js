var searchData=
[
  ['debugdataset_0',['debugDataset',['../ml-naive-bayes_8h.html#a39fc66cfb4519ce0e0840bc766cb79e0',1,'debugDataset(struct Dataset *data, int len):&#160;ml-naive-bayes.c'],['../ml-naive-bayes_8c.html#a39fc66cfb4519ce0e0840bc766cb79e0',1,'debugDataset(struct Dataset *data, int len):&#160;ml-naive-bayes.c']]],
  ['dobotmove_1',['doBOTmove',['../main_8h.html#af76f1698e679941c21085657b6d98473',1,'doBOTmove():&#160;main.c'],['../main_8c.html#af76f1698e679941c21085657b6d98473',1,'doBOTmove():&#160;main.c']]]
];
