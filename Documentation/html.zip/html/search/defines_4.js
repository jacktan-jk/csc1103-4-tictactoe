var searchData=
[
  ['file_5fbestmov_0',['FILE_BESTMOV',['../minimax_8h.html#a639effcb37d2b98906303fecdb9c9f5e',1,'minimax.h']]]
];
