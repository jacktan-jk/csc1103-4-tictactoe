var searchData=
[
  ['data_5fpath_0',['DATA_PATH',['../import_data_8h.html#ac26a668e32beeb7eae8b6e4adbe5d1e1',1,'importData.h']]],
  ['data_5fsize_1',['DATA_SIZE',['../macros_8h.html#af55149bc1f05cf18af067a302e31e3f9',1,'macros.h']]],
  ['debug_2',['DEBUG',['../macros_8h.html#ad72dbcf6d0153db1b8d8a58001feed83',1,'macros.h']]],
  ['disable_5fasm_3',['DISABLE_ASM',['../macros_8h.html#a5ae05ae4c72cd9ae5147a40a1436cef6',1,'macros.h']]],
  ['disable_5felapsed_4',['DISABLE_ELAPSED',['../macros_8h.html#aacc47b301ed91254362ba4f2cd7efc75',1,'macros.h']]],
  ['disable_5flookup_5',['DISABLE_LOOKUP',['../macros_8h.html#a47dca33d219deb503db9c9d808b24356',1,'macros.h']]]
];
