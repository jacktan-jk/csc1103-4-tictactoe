var main_8c =
[
    [ "chkPlayerWin", "main_8c.html#ab3744385ac07502d3920342e20805ec7", null ],
    [ "clearGrid", "main_8c.html#ad28c8c932b46ed4bce19748ba7106599", null ],
    [ "doBOTmove", "main_8c.html#af76f1698e679941c21085657b6d98473", null ],
    [ "main", "main_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "on_btnGrid_clicked", "main_8c.html#a20666861ea3282632824204e33c1411a", null ],
    [ "on_btnScore_clicked", "main_8c.html#a771f6ad36f989d0b7d43aa9a6eea439f", null ],
    [ "showWin", "main_8c.html#a12b7b398d9794dcc293ded8fa9c76989", null ],
    [ "updateScoreBtn", "main_8c.html#acc414f6dda9b801014f13c0bf1f14740", null ],
    [ "btnGrid", "main_8c.html#a7deca23032284da0ca814198f21f592c", null ],
    [ "iBoard", "main_8c.html#adc21ea5cc28327a21455788fa1b9518f", null ],
    [ "iGameState", "main_8c.html#a80fa44672f562631d6347fc01e0c9a8a", null ],
    [ "iPlayer1_score", "main_8c.html#ae1d310ad434c7a2f6b36903df0e48f7f", null ],
    [ "iPlayer2_score", "main_8c.html#a8ef9076ab0a4dabeb8638b2295ccd7e8", null ],
    [ "isMLAvail", "main_8c.html#a3b5a2ec67eaad775b0eedc6c869b0efa", null ],
    [ "isPlayer1Turn", "main_8c.html#ac7d33f5c85beb77a9f9b399811ee34c6", null ],
    [ "iTie_score", "main_8c.html#a95f308163088cd3cc0aee84261b02030", null ],
    [ "iWinPos", "main_8c.html#a300a754c6a50ee6fc5e78bd8caf55f3b", null ],
    [ "playerMode", "main_8c.html#a5e71fc65a887b894007f895ddcd5831e", null ]
];