var main_8h =
[
    [ "BtnPos", "struct_btn_pos.html", "struct_btn_pos" ],
    [ "PlayerMode", "struct_player_mode.html", "struct_player_mode" ],
    [ "chkPlayerWin", "main_8h.html#ab3744385ac07502d3920342e20805ec7", null ],
    [ "clearBtn", "main_8h.html#a405ebfe803495334bf56cfd62f72a5ad", null ],
    [ "doBOTmove", "main_8h.html#af76f1698e679941c21085657b6d98473", null ],
    [ "on_btnGrid_clicked", "main_8h.html#a20666861ea3282632824204e33c1411a", null ],
    [ "on_btnScore_clicked", "main_8h.html#a771f6ad36f989d0b7d43aa9a6eea439f", null ],
    [ "showWin", "main_8h.html#a12b7b398d9794dcc293ded8fa9c76989", null ],
    [ "updateScoreBtn", "main_8h.html#acc414f6dda9b801014f13c0bf1f14740", null ]
];