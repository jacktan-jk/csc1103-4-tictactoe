/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "TicTacToe", "index.html", [
    [ "TIC TAC TOE - CSC1103 & CSC1104 Project", "index.html#tic-tac-toe---csc1103--csc1104-project", [
      [ "Installation Instructions (Linux)", "index.html#installation-instructions-linux", [
        [ "Building the Project via Docker (Linux)", "index.html#building-the-project-via-docker-linux", [
          [ "[OPTIONAL] Loading Docker Image", "index.html#optional-loading-docker-image", null ],
          [ "Build and Run TicTacToe Application on Docker (Linux)", "index.html#build-and-run-tictactoe-application-on-docker-linux", null ]
        ] ]
      ] ],
      [ "Installation Instructions (MacOS)", "index.html#installation-instructions-macos", [
        [ "Run TicTacToe Application on Docker (MacOS)", "index.html#run-tictactoe-application-on-docker-macos", null ]
      ] ],
      [ "Installation Instructions (Windows)", "index.html#installation-instructions-windows", [
        [ "Building the Project via Docker (Windows)", "index.html#building-the-project-via-docker-windows", [
          [ "[OPTIONAL] Loading Docker Image", "index.html#optional-loading-docker-image-1", null ],
          [ "Build and Run TicTacToe Application on Docker (Windows)", "index.html#build-and-run-tictactoe-application-on-docker-windows", null ]
        ] ],
        [ "Build and Run the Project in Windows (w/o Docker)", "index.html#build-and-run-the-project-in-windows-wo-docker", null ]
      ] ],
      [ "BASIC REQUIREMENTS (BOTH)", "index.html#basic-requirements-both", null ],
      [ "[^1]PM-CSC1103 REQUIRMENTS", "index.html#autotoc_md1pm-csc1103-requirments", null ],
      [ "[^2]COA-CSC1104 REQUIRMENTS", "index.html#autotoc_md2coa-csc1104-requirments", null ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';