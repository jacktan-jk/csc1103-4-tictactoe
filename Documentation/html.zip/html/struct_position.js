var struct_position =
[
    [ "col", "struct_position.html#afb52e720f5f0c483db5861f9e42e924e", null ],
    [ "row", "struct_position.html#af1d3cff2e4538e23400e260bae3dadad", null ]
];