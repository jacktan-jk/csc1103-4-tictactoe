var files_dup =
[
    [ "Documentation", "dir_f9dfd35b172a0e2036ace76497fb239b.html", null ],
    [ "header", "dir_1ec98ce50fa6ec55b40b8ffb1df38c3c.html", "dir_1ec98ce50fa6ec55b40b8ffb1df38c3c" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ]
];